<?php
// ************************************
// This file is part of a package from:
// www.majesticform.com

// Free Version
// 2 January 2022

// You are free to use an edit for 
// your own use. But cannot resell
// or repackage in any way.
// ************************************

require dirname(__FILE__).'/'.'fcf.config.php';
require dirname(__FILE__).'/'.'process.php';