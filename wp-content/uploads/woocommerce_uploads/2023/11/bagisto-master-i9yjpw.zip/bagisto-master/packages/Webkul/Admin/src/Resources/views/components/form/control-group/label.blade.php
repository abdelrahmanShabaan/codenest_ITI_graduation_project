<label {{ $attributes->merge(['class' => 'block leading-[24px] text-[12px] text-gray-800 dark:text-white font-medium']) }}>
    {{ $slot }}
</label>
