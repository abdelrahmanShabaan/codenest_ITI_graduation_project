# Reporting Security Issues

Bagisto values the contributions of the security research community, and we look forward to working with you to minimize risk to Bagisto merchants.

## Where should I report security issues?

If you think that you have found a security issue in Bagisto, please do not use the issue tracker and do not post it publicly. Instead, all security issues must be sent to mailto:support@bagisto.com.
