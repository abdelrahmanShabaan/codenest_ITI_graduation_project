<?php

get_header();

?>
<div id="primary">
	<main id="main" class="site-main mt-5" role="main">
		<div class="flex text-center">Hello world</div>
	</main>
</div>
<?php

get_footer();
