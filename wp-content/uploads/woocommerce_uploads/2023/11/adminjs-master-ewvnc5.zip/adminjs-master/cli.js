#!/usr/bin/env node
// eslint-disable-next-line
import('./lib/cli')
