import AdminJS from './lib/index.js'

export * from './lib/index.js'

export {
  AdminJS,
}

export default AdminJS
