import React from 'react'

function ExampleComponent() {
  return <div>Some example text</div>
}

export default ExampleComponent
