export * from './property-label.js'
