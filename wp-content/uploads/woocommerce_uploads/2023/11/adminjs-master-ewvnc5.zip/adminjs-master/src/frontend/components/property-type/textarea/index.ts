import Show from './show.js'
import Edit from './edit.js'

export {
  Show as show,
  Edit as edit,
}
