/* eslint-disable import/prefer-default-export */
import Edit from './edit.js'

export {
  Edit as edit,
}
