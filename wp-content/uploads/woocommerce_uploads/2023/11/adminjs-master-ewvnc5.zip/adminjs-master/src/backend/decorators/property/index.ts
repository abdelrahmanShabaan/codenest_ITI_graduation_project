export { PropertyDecorator } from './property-decorator.js'
export type { default as PropertyOptions } from './property-options.interface.js'
export * from './property-options.interface.js'
