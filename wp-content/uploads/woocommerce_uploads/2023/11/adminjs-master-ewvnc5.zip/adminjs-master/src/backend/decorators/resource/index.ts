export { default as ResourceDecorator } from './resource-decorator.js'
export * from './resource-options.interface.js'
