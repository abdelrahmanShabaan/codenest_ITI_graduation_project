const DELIMITER = '.'

export { DELIMITER }
