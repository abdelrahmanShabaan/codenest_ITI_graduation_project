export * from './property-description.js'
