import Edit from './edit.js'
import List from './list.js'
import Show from './show.js'

export {
  Show as show,
  Edit as edit,
  List as list,
}
