import Edit from './edit.js'
import Show from './show.js'

export {
  Edit as edit,
  Show as show,
}
