export { default as BaseProperty } from './base-property.js'
export type { PropertyType } from './base-property.js'
