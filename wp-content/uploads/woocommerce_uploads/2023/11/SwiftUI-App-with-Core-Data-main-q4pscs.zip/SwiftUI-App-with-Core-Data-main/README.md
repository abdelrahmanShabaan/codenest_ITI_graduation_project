# SwiftUI-App-with-Core-Data
Sample XCode 12 iOS App that uses the SwiftUI App Life Cycle with Core Data
