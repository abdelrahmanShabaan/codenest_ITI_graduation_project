<h1 align="center">Inventory Management System</h1>

<p align="center">
    POS
</p>

## About this application

This project is prepared in the learning purpose. It is aimed at developing a desktop based application named Inventory Management System for managing the inventory system of any organization. The Inventory Management System (IMS) refers to the system and processes to manage the stock of organization with the involvement of Technology system. This system can be used to store the details of the inventory, stock maintenance, purchase maintenance update the inventory based on the sales details, generate sales and inventory report daily, weekly or any time period based. It can maintain the credit customers statements properly. Its developed in learning purpose so not much useful features available here but I tried to do my best. Hope more will come in the future.
