<?php
/**
 * Created by PhpStorm.
 * User: QUDUS
 * Date: 2/16/2019
 * Time: 1:42 AM
 */

//return [
//    'administrators' => [
//        'kati@frantz.com',
//        'kati-frantz@mymail.com'
//    ]
//];

return array(
    'pagination' => array(
        'ade@gmail.com'
    ),
);