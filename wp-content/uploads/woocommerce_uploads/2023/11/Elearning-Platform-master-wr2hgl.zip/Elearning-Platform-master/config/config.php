<?php
/**
 * Created by PhpStorm.
 * User: QUDUS
 * Date: 2/16/2019
 * Time: 1:35 AM
 */

return [
    'administrators' => [
        'ade@gmail.com',
        'yunus@gmail.com'
    ]
];