**To get the project up and running, Do the following After Cloning:**

- `composer install`

- `npm  install`

- `cp .env.example .env` _(Then setup ur .env file)_

- `php artisan key:generate`

- `php artisan migrate`

- `php artisan db:seed` _(Seed some files to your db)_

- Register a user 



