<?php

// connect database --> get data from table  
    require_once("config.php"); // connection database 
    $sql = "select * from students";
                //  connection, query 
    $result = mysqli_query($conncetion, $sql) or die(mysqli_error($conncetion)); 
   
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <a href="create.php"> Create User </a>

    <center> 
        <table border=1>
            <tr>
                <td>Name</td>
                <td>Email</td>
                <td>phone</td>
                <td>Delete User</td>
                <td>Edit User</td>
            </tr>
            <?php 
                while($usersInfo = mysqli_fetch_array($result)){
                echo "<tr>";
                echo "<td>".  $usersInfo["name"]  ."</td>";
                echo "<td>".  $usersInfo["email"]  ."</td>";
                echo "<td>".  $usersInfo["phone"]  ."</td>";
                echo "<td> <a href='delete.php?userid=$usersInfo[id]'> Delete </a> </td>"; // send id in the url 
                echo "<td> <a href='edit.php?userid=$usersInfo[id]'> Edit </a> </td>";
                echo "</tr>";
            }
            ?>

        </table>
    </center>
</body>
</html>